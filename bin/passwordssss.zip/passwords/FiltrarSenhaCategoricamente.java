package passwords;

import java.io.*;

public class FiltrarSenhaCategoricamente {
	public static void main(String[] args) {
		
		String arquivo4 = "files/passwords_formated_data.csv";
		String arquivo5 = "files/passwords_classifier.csv";
		
		try(BufferedReader br = new BufferedReader(new FileReader(arquivo4));
				BufferedWriter bw = new BufferedWriter(new FileWriter(arquivo5))) {
				
				String linha;
				
				bw.write("position,password,length,class,data\n");
			
		}catch(IOException e) {
			
		}
	}
}
