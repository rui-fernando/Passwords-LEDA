package passwords;

import java.io.*;
//
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

//deu erro, não está formatando YYYY/MM/DD HH:MM:SS para DD/MM/YYYY

public class TransformacoesDeDatas {
	public static void main(String[] args) {
		
		String arquivo2 = "files/password_classifier.csv";
		String arquivo3 = "files/passwords_formated_data.csv";
		
		try(BufferedReader br = new BufferedReader(new FileReader(arquivo2));
				BufferedWriter bw = new BufferedWriter(new FileWriter(arquivo3))) {
					
				String linha;		
				bw.write("position,password,length,class,data\n");
				linha = br.readLine();	
				while ((linha = br.readLine()) != null) {
					String[] colunas = linha.split(",");
					
					if (colunas.length < 5) {
						System.err.println("Linha ignorada: formato inválido!" + linha);
						continue;
					}
					
					String posicao = colunas[0];
					String senha = colunas[1];
					String tamanho = colunas[2];
					String dataoriginal = colunas[3];
					String classificacao = colunas[4];
					
					String dataformatada = formatarData(dataoriginal);
					bw.write(posicao + "," + senha + "," + tamanho + "," + dataformatada + "," + classificacao + "\n");
				}
				System.out.println("Transformações de datas concluídas com sucesso. Arquivo gerado: passwords_formated_data.csv.");
			
			} catch (IOException e) {
			
				e.printStackTrace();
			}
							
	}
    
	public static String formatarData(String dataOriginal) {
        if (dataOriginal == null || dataOriginal.isEmpty()) {
            return "Data inválida"; // Retorna um aviso se a data estiver vazia
        }

        try {
            // Define o formato de entrada considerando a hora
            DateTimeFormatter formatoOriginal = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
            // Define o novo formato desejado
            DateTimeFormatter formatoDesejado = DateTimeFormatter.ofPattern("dd/MM/yyyy");

            // Converte a string para LocalDate e formata
            return LocalDate.parse(dataOriginal.substring(0, 10), DateTimeFormatter.ofPattern("yyyy-MM-dd"))
                            .format(formatoDesejado);
        } catch (DateTimeParseException e) {
            return "Erro ao converter data"; // Caso a data esteja em formato inesperado
        }
    }
}
